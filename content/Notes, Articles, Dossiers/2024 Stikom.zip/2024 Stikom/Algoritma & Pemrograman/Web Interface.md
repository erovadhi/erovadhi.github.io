1. Halaman Back-End diakses oleh admin.
2. Untuk Menampilkan Halaman Web ke layar monitor menggunakan Browser.
3. Untuk merancang/menuliskan program tampilan halaman web menggunakan text editor.
4. Aplikasi untuk membuat efek suara adalah aplikasi audio (Adobe Audition).
5.  Contoh aplikasi grafis (mendesain ikon-ikon web) Adobe Photoshop, Adobe Illustrator.
6. Aplikasi designer web adalah Adobe Dreamweaver.
7.  Aplikasi pemutar multimedia (Berbagai format media) yaitu adobe flash.
8.  Sebuah halaman yang tersusun saling terkait satu dengan yang lainnya, serta mempunyai konten yang unik, merupakan definisi dari web.
9. Contoh aplikasi _web server_ adalah Apache Friend XAMPP.
10. Halaman Web dinamis adalah halaman web yang dapat berubah sesuai interaksi dari penggunanya.
11. Halaman Front-End adalah halaman web yang dibuat semenarik mungkin yang ditujukan untuk ditampilkan kepada klien/pengguna. Halaman ini biasa memiliki link/hubungan untuk mengambil data dari Back-End untuk ditampilkan di halaman web.
12. Halaman web bernama server web adalah halaman Back-End.
13. Halaman WEB yang dinamakan _client web_ adalah Front-End.
14. Urutan yang benar dalam membuat halaman _web_ berbasis _server_ adalah Jalankan web server > jalankan text editor > jalankan web browser.